# LoongForge PI05 控制台

独立于 PI0 控制台，默认端口 8901。只调用本机 LoongForge 的 PI05 训练配方和 LIBERO 原生评测，不修改模型仓库实现。

```bash
cd /home/gm/data/LoongForge/LoongForge/debug_web_pi05
bash run.sh
bash stop.sh
```

停止网页服务不会停止训练/评测；再次启动会恢复任务记录。网页内“停止”只作用于此控制台创建的任务。已有外部实验仅查看。

- 总览：自动发现 PI05 checkpoint、数据集与已有实验，查看 loss、梯度、吞吐、NaN/跳过更新、逐任务成功率、失败原因和评测视频文件。
- 训练：DDP、ZeRO-1、FSDP；指定 GPU、学习率、batch、梯度累积、保存间隔、冻结项。有效 batch = 每卡 batch × 卡数 × 累积步数。续训填写原输出目录并勾选续训，总步数须大于已完成步数。
- 评测：当前支持 LIBERO-10，先用 1 任务 × 1 episode 验证，再扩大规模。使用独立策略服务端口。PI05 状态为末端位置3 + 轴角3 + 双指2，q99 归一化后进入语言提示；默认 FP32，与机器现有成功运行配置一致。
- 评测先用临时硬链接固定权重（跨文件系统时复制），防止加载期间原 checkpoint 被清理；评测退出自动释放该临时链接。
- 原生训练权重带 model./pi05. 别名时，评测前写入独立转换缓存，原始 checkpoint 不变。
- 运行前检查可预览完整命令、环境和评测配置；任务输出保存 console_plan、评测配置，便于复现。检查不加载完整模型，不验证显存或真实成功率。
- 训练图显示最近 3000 条指标；评测汇总读取最多最近 10000 条/8MiB结果，按 episode_id 去重。最多10任务×50次；特别大的历史结果需使用原始文件分析。
- 配置保存在 config.json；网页日志 runtime/server.log；任务日志 runtime/jobs/；转换缓存 runtime/converted/。

默认 GPU 3 仅为预填值，启动前查看显存和利用率并选卡。服务供可信内网使用，没有账号登录。

测试（CPU，不启动真实训练/评测）：
```bash
/home/gm/data/LoongForge/env/bin/python -m unittest discover -s tests -v
```
